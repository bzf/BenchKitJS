CanvasMark
==========

CanvasMark 2013 - Benchmark tool for HTML5 canvas 2D performance testing. As used by tomshardware.com and Mozilla.

http://www.kevs3d.co.uk/dev/canvasmark
https://github.com/kevinroast/CanvasMark

