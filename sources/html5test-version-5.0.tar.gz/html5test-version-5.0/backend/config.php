<?php

	$version = '5.00';
	$readonly = false;
	
	$mysql['server'] = 'localhost';
	$mysql['username'] = '******';
	$mysql['password'] = '******';
	$mysql['database'] = '******';

	