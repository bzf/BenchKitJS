<?php

	mysql_connect($mysql['server'], $mysql['username'], $mysql['password']);
	mysql_select_db($mysql['database']);
